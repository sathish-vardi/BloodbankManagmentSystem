package com.tectoro.bloodbankmanagmentsystem.domain;

public class DonationCarddomain {

	private int donorCardId;
	Donardomain donars;

	public Donardomain getDonars() {
		return donars;
	}

	public void setDonars(Donardomain donars) {
		this.donars = donars;
	}

	public int getDonorCardId() {
		return donorCardId;
	}

	public void setDonorCardId(int donorCardId) {
		this.donorCardId = donorCardId;
	}

}
