package com.tectoro.bloodbankmanagmentsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.tectoro.bloodbankmanagmentsystem.dao.BloodTypeDao;
import com.tectoro.bloodbankmanagmentsystem.dao.DonarDao;
import com.tectoro.bloodbankmanagmentsystem.dao.RecipientDao;
import com.tectoro.bloodbankmanagmentsystem.dao.RecipientTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;

@Repository
public class BloodTypeDaoImpl implements BloodTypeDao {

	@Autowired
	private JdbcTemplate template;
	@Autowired
	private RecipientTransactionDao dao;
	@Autowired
	private RecipientDao dao1;
	@Autowired
	private DonarDao dao2;

	@Override
	public BloodTypedomain addBloodType(BloodTypedomain bloodtype) {

		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert ");
			sqlQuery.append("into ");
			sqlQuery.append("bloodtype ");
			sqlQuery.append("(name) ");
			sqlQuery.append("values(?)");

			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(sqlQuery.toString(), new String[] { "blood_type_id" });
					ps.setString(1, bloodtype.getName());
					return ps;
				}
			}, keyHolder);
			bloodtype.setBlood_type_id(keyHolder.getKey().intValue());

		} catch (Exception e) {
			e.printStackTrace();
		}

		return bloodtype;
	}

	@Override
	public BloodTypedomain updateBloodType(BloodTypedomain domain) {
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("update ");
			sqlQuery.append("bloodtype ");
			sqlQuery.append("set name =");
			sqlQuery.append("'" + domain.getName() + "'");
			sqlQuery.append("where ");
			sqlQuery.append("blood_type_id =");
			sqlQuery.append(domain.getBlood_type_id());
			template.execute(sqlQuery.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public BloodTypedomain getBloodType(Integer domain) {

		BloodTypedomain domain1 = null;
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("bloodtype ");
			sqlQuery.append("where ");
			sqlQuery.append("blood_type_id =");
			sqlQuery.append(domain);
			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<BloodTypedomain>() {

				@Override
				public BloodTypedomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					BloodTypedomain res = new BloodTypedomain();
					while (rs.next()) {
						res.setBlood_type_id(rs.getInt("blood_type_id"));
						res.setName(rs.getString("name"));
					}
					return res;
				}
			});

		} catch (Exception e) {
			throw e;
		}
		return domain1;
	}

	@Override
	public int deleteBloodType(Integer blood_type_id) {

		int flag = 0;
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("delete ");
			sqlQuery.append("from ");
			sqlQuery.append("bloodtype ");
			sqlQuery.append("where ");
			sqlQuery.append("blood_type_id =");
			sqlQuery.append(blood_type_id);

			flag = dao.deleteTransaction(blood_type_id);
			if (flag == 1) {
				flag += dao1.deleteRecipent(blood_type_id);
				if (flag == 2) {
					flag += dao2.deleteDonar(blood_type_id);
				}
				if (flag == 3) {
					template.update(sqlQuery.toString());
					flag = 1;
					return flag;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public String CheckBloodType(String name) {
		
		BloodTypedomain domain1 = null;
		int flag = 0;
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select * from ");
			sqlQuery.append("bloodtype ");
			sqlQuery.append("where ");
			sqlQuery.append("name =");
			sqlQuery.append("'" + name + "'");

			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<BloodTypedomain>() {

				@Override
				public BloodTypedomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					BloodTypedomain res = new BloodTypedomain();
					while (rs.next()) {
						res.setBlood_type_id(rs.getInt("blood_type_id"));
						res.setName(rs.getString("name"));
					}
					return res;
				}
			});
			if(domain1!=null) {
			if (domain1.getBlood_type_id() != 0 && domain1.getName() != null) {
				return "we have this " + name + " blood group";
			} else {
				return "we dont have this " + name + " blood group";
			}
			}else {
				return "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
