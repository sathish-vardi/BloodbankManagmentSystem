package com.tectoro.bloodbankmanagmentsystem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tectoro.bloodbankmanagmentsystem.dao.RecipientDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Recipientdomain;
import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;
import com.tectoro.bloodbankmanagmentsystem.model.RecipientModel;
import com.tectoro.bloodbankmanagmentsystem.service.RecipentService;

@Service
public class RecipentServiceImpl implements RecipentService {

	@Autowired
	private RecipientDao dao;

	@Override
	public RecipientModel addrecipent(RecipientModel recipent) {

		Recipientdomain domain = new Recipientdomain();
		domain.setContactNumber(recipent.getContactNumber());
		domain.setName(recipent.getName());
		BloodTypedomain bloodTypedomain = new BloodTypedomain();
		bloodTypedomain.setBlood_type_id(Integer.parseInt(recipent.getBloodtypes().getBlood_type_id()));
		domain.setBloodtypes(bloodTypedomain);
		Donardomain donardomain = new Donardomain();
		donardomain.setDonor_id(Integer.parseInt(recipent.getDonars().getDonor_id()));
		domain.setDonars(donardomain);
		dao.addrecipent(domain);

		RecipientModel model = new RecipientModel();
		model.setRecipentID(String.valueOf(domain.getRecipentID()));
		model.setName(domain.getName());
		model.setContactNumber(domain.getContactNumber());
		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(domain.getBloodtypes().getBlood_type_id()));
		model.setBloodtypes(bloodTypemodel);
		Donarmodel donarmodel = new Donarmodel();
		donarmodel.setDonor_id(String.valueOf(domain.getDonars().getDonor_id()));
		model.setDonars(donarmodel);

		return model;
	}

	@Override
	public RecipientModel getRecipent(int recipentID) {
		Recipientdomain recipientdomain = new Recipientdomain();
		recipientdomain = dao.getRecipent(recipentID);

		RecipientModel model = new RecipientModel();
		model.setRecipentID(String.valueOf(recipientdomain.getRecipentID()));
		model.setContactNumber(recipientdomain.getContactNumber());
		model.setName(recipientdomain.getName());
		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(recipientdomain.getBloodtypes().getBlood_type_id()));
		model.setBloodtypes(bloodTypemodel);
		Donarmodel donarmodel = new Donarmodel();
		donarmodel.setDonor_id(String.valueOf(recipientdomain.getDonars().getDonor_id()));
		model.setDonars(donarmodel);

		return model;
	}

	@Override
	public RecipientModel updaterecipent(RecipientModel recipientModel) {
		Recipientdomain recipientdomain = new Recipientdomain();
		recipientdomain.setRecipentID(Integer.parseInt(recipientModel.getRecipentID()));
		if (recipientModel.getBloodtypes().getBlood_type_id() != null) {
			BloodTypedomain typedomain = new BloodTypedomain();
			typedomain.setBlood_type_id(Integer.parseInt(recipientModel.getBloodtypes().getBlood_type_id()));
			recipientdomain.setBloodtypes(typedomain);
		}
		if (recipientModel.getContactNumber() != null) {
			recipientdomain.setContactNumber(recipientModel.getContactNumber());
		}
		if (recipientModel.getName() != null) {
			recipientdomain.setName(recipientModel.getName());
		}
		if (recipientModel.getDonars().getDonor_id() != null) {
			Donardomain donardomain = new Donardomain();
			donardomain.setDonor_id(Integer.parseInt(recipientModel.getDonars().getDonor_id()));
			recipientdomain.setDonars(donardomain);
		}
		dao.updateRecipent(recipientdomain);

		RecipientModel model = new RecipientModel();
		model.setContactNumber(recipientdomain.getContactNumber());
		model.setName(recipientdomain.getName());
		model.setRecipentID(String.valueOf(recipientdomain.getRecipentID()));
		BloodTypemodel typemodel = new BloodTypemodel();
		typemodel.setBlood_type_id(String.valueOf(recipientdomain.getBloodtypes().getBlood_type_id()));
		model.setBloodtypes(typemodel);

		Donarmodel donarmodel = new Donarmodel();
		donarmodel.setDonor_id(String.valueOf(recipientdomain.getDonars().getDonor_id()));
		model.setDonars(donarmodel);

		return model;
	}

	@Override
	public int deleteRecipent(int bloodtypeid) {
		
		return dao.deleteRecipent(bloodtypeid);
	}
	

}
