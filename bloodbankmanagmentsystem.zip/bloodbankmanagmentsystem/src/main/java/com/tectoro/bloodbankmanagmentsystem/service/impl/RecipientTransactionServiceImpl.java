package com.tectoro.bloodbankmanagmentsystem.service.impl;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tectoro.bloodbankmanagmentsystem.dao.RecipientTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.DonationCarddomain;
import com.tectoro.bloodbankmanagmentsystem.domain.RecipientTransactiondomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Recipientdomain;
import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;
import com.tectoro.bloodbankmanagmentsystem.model.DonationCardModel;
import com.tectoro.bloodbankmanagmentsystem.model.RecipientModel;
import com.tectoro.bloodbankmanagmentsystem.model.RecipientTransactionModel;
import com.tectoro.bloodbankmanagmentsystem.service.RecipientTransactionService;

@Service
public class RecipientTransactionServiceImpl implements RecipientTransactionService {

	@Autowired
	private RecipientTransactionDao dao;

	@Override
	public void addTransaction(RecipientTransactionModel transaction) {
		RecipientTransactiondomain domain = new RecipientTransactiondomain();
		domain.setDate(Date.valueOf(transaction.getDate()));
		domain.setRecipientRequest(transaction.getRecipientRequest());
		BloodTypedomain bloodTypedomain = new BloodTypedomain();
		bloodTypedomain.setBlood_type_id(Integer.parseInt(transaction.getBloodtypes().getBlood_type_id()));
		domain.setBloodtypes(bloodTypedomain);
		Recipientdomain recipientdomain = new Recipientdomain();
		recipientdomain.setRecipentID(Integer.parseInt(transaction.getRecepients().getRecipentID()));
		domain.setRecepients(recipientdomain);
		DonationCarddomain carddomain = new DonationCarddomain();
		carddomain.setDonorCardId(Integer.parseInt(transaction.getDonationcards().getDonorCardId()));
		domain.setDonationcards(carddomain);
		dao.addRecipient(domain);

		RecipientTransactionModel model = new RecipientTransactionModel();
		model.setRecipientTransId(String.valueOf(domain.getRecipientTransId()));
		model.setDate(String.valueOf(domain.getDate()));
		model.setRecipientRequest(domain.getRecipientRequest());
		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(domain.getBloodtypes().getBlood_type_id()));
		model.setBloodtypes(bloodTypemodel);
		DonationCardModel carddomain2 = new DonationCardModel();
		carddomain2.setDonorCardId(String.valueOf(domain.getDonationcards().getDonorCardId()));
		model.setDonationcards(carddomain2);
		RecipientModel recipientdomain2 = new RecipientModel();
		recipientdomain2.setRecipentID(String.valueOf(domain.getRecepients().getRecipentID()));
		model.setRecepients(recipientdomain2);

	}

	@Override
	public RecipientTransactionModel getRecipient(int recipientTransId) {

		RecipientTransactiondomain domain = new RecipientTransactiondomain();
		domain = dao.getrecipientTransaction(recipientTransId);

		RecipientTransactionModel model = new RecipientTransactionModel();
		model.setDate(String.valueOf(domain.getDate()));
		model.setRecipientRequest(domain.getRecipientRequest());
		model.setRecipientTransId(String.valueOf(domain.getRecipientTransId()));
		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(domain.getBloodtypes().getBlood_type_id()));
		model.setBloodtypes(bloodTypemodel);
		DonationCardModel carddomain2 = new DonationCardModel();
		carddomain2.setDonorCardId(String.valueOf(domain.getDonationcards().getDonorCardId()));
		model.setDonationcards(carddomain2);
		RecipientModel recipientdomain2 = new RecipientModel();
		recipientdomain2.setRecipentID(String.valueOf(domain.getRecepients().getRecipentID()));
		model.setRecepients(recipientdomain2);
		return model;
	}

	@Override
	public RecipientTransactionModel updaterecipentTransaction(RecipientTransactionModel model) {
		RecipientTransactiondomain domain = new RecipientTransactiondomain();
		domain.setRecipientTransId(Integer.parseInt(model.getRecipientTransId()));
		if (model.getDate() != null) {
			domain.setDate(Date.valueOf(model.getDate()));
		}
		if (model.getRecipientRequest() != null) {
			domain.setRecipientRequest(model.getRecipientRequest());
		}
		if (model.getBloodtypes().getBlood_type_id() != null) {
			BloodTypedomain bloodTypedomain = new BloodTypedomain();
			bloodTypedomain.setBlood_type_id(Integer.valueOf(model.getBloodtypes().getBlood_type_id()));
			domain.setBloodtypes(bloodTypedomain);
		}
		if (model.getDonationcards().getDonorCardId() != null) {
			DonationCarddomain carddomain = new DonationCarddomain();
			carddomain.setDonorCardId(Integer.parseInt(model.getDonationcards().getDonorCardId()));
			domain.setDonationcards(carddomain);
		}
		if (model.getRecepients().getRecipentID() != null) {
			Recipientdomain recipientdomain = new Recipientdomain();
			recipientdomain.setRecipentID(Integer.parseInt(model.getRecepients().getRecipentID()));
			domain.setRecepients(recipientdomain);
		}
		dao.updateRecipentTransaction(domain);

		RecipientTransactionModel model2 = new RecipientTransactionModel();
		model2.setRecipientTransId(String.valueOf(domain.getRecipientTransId()));
		model2.setRecipientRequest(domain.getRecipientRequest());
		model.setDate(String.valueOf(domain.getDate()));
		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(domain.getBloodtypes().getBlood_type_id()));
		model2.setBloodtypes(bloodTypemodel);
		DonationCardModel carddomain2 = new DonationCardModel();
		carddomain2.setDonorCardId(String.valueOf(domain.getDonationcards().getDonorCardId()));
		model2.setDonationcards(carddomain2);
		RecipientModel recipientdomain2 = new RecipientModel();
		recipientdomain2.setRecipentID(String.valueOf(domain.getRecepients().getRecipentID()));
		model2.setRecepients(recipientdomain2);

		return model2;
	}

	@Override
	public int deleteTransaction(int recipient_trans_id) {

		return dao.deleteTransaction(recipient_trans_id);
	}

	@Override
	public String CheckingDate(int recipientTransId) {
		return dao.CheckingDate(recipientTransId);
	}

}
