package com.tectoro.bloodbankmanagmentsystem.service;

import com.tectoro.bloodbankmanagmentsystem.model.RecipientTransactionModel;

public interface RecipientTransactionService {

	void addTransaction(RecipientTransactionModel transaction);

	RecipientTransactionModel getRecipient(int recipientTransId);

	RecipientTransactionModel updaterecipentTransaction(RecipientTransactionModel model);

	int deleteTransaction(int recipient_trans_id);

	String CheckingDate(int recipientTransId);

}
