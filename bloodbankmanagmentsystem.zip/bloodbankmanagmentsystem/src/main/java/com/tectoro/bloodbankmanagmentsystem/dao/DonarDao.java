package com.tectoro.bloodbankmanagmentsystem.dao;

import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;

public interface DonarDao {
	
	public Donardomain addDonar(Donardomain donars);

	public Donardomain getDonar(Integer donor_id);

	public Donardomain updateDonar(Donardomain donar);

	public int deleteDonar(int bloodtypeid);

	public int deleteDonarByDonarID(int donor_id);

}
