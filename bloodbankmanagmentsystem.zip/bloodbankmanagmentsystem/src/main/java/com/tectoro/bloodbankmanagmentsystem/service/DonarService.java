package com.tectoro.bloodbankmanagmentsystem.service;

import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;

public interface DonarService {
	
	public Donarmodel addDonar(Donarmodel donarmodel);

	public Donarmodel getDonar(Integer donor_id);

	public Donarmodel updateDonar(Donarmodel donar);

	public String deleteDonarByDonarID(int donor_id) throws Exception;

}
