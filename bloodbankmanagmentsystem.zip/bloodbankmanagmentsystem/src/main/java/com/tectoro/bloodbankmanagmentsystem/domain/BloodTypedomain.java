package com.tectoro.bloodbankmanagmentsystem.domain;

import java.util.List;

public class BloodTypedomain {
	private int blood_type_id;
	private String name;

	public int getBlood_type_id() {
		return blood_type_id;
	}

	public void setBlood_type_id(int blood_type_id) {
		this.blood_type_id = blood_type_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
