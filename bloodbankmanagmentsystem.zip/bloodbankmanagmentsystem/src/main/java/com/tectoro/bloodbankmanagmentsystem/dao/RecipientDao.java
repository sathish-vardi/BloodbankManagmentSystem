package com.tectoro.bloodbankmanagmentsystem.dao;

import java.util.List;

import com.tectoro.bloodbankmanagmentsystem.domain.Recipientdomain;

public interface RecipientDao {

	Recipientdomain addrecipent(Recipientdomain recipent);

	Recipientdomain getRecipent(int recipentID);

	Recipientdomain updateRecipent(Recipientdomain recipientdomain);

	int deleteRecipent(int bloodtypeid);

	List<Integer> deleteRecipentByDonarId(int donor_id);

}
