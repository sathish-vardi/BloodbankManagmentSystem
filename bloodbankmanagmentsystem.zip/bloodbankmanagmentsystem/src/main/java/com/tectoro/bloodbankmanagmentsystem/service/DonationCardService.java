package com.tectoro.bloodbankmanagmentsystem.service;

import com.tectoro.bloodbankmanagmentsystem.model.DonationCardModel;

public interface DonationCardService {

	DonationCardModel addDonationCard(DonationCardModel cardModel);

	DonationCardModel getDonation(int donorCardId);

}
