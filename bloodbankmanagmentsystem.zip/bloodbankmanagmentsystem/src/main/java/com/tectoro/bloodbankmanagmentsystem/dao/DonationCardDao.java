package com.tectoro.bloodbankmanagmentsystem.dao;

import com.tectoro.bloodbankmanagmentsystem.domain.DonationCarddomain;
import com.tectoro.bloodbankmanagmentsystem.model.DonationCardModel;

public interface DonationCardDao {

	DonationCarddomain getaddDonationCard(DonationCarddomain carddomain);

	DonationCarddomain getDonation(int donorCardId);

	int deleteDonationCardByDonarID(int donor_id);

	int deleteDonationCard(int donor_id);

}
