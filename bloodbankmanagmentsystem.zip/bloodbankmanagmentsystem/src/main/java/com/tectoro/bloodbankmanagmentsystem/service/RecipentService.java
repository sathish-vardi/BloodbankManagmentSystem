package com.tectoro.bloodbankmanagmentsystem.service;

import com.tectoro.bloodbankmanagmentsystem.model.RecipientModel;

public interface RecipentService {

	RecipientModel addrecipent(RecipientModel recipent);

	RecipientModel getRecipent(int recipentID);

	RecipientModel updaterecipent(RecipientModel recipientModel);

	int deleteRecipent(int bloodtypeid);

}
