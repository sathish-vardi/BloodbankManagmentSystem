package com.tectoro.bloodbankmanagmentsystem.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;
import com.tectoro.bloodbankmanagmentsystem.service.BloodTypeService;

@RestController
@RequestMapping("/bloodtype")
public class BloodTypeController {

	@Autowired
	private BloodTypeService service;

	@PostMapping("/addbloodtype")
	public BloodTypemodel addBloodType(@RequestBody BloodTypemodel bloodtype) {
		BloodTypemodel model = null;
		try {

			model = service.addBloodType(bloodtype);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return model;
	}

	@PutMapping("/updatebloodtype")
	public BloodTypemodel updateBloodType(@RequestBody BloodTypemodel bloodtype) {
		BloodTypemodel model = null;
		try {
			model = service.updateBloodType(bloodtype);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}

	@GetMapping("/getbloodtype")
	public BloodTypemodel getBloodType(@RequestParam("blood_type_id") int blood_type_id) {
		BloodTypemodel model = null;
		try {
			model = service.getBloodType(blood_type_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@DeleteMapping("/deleteblootype")
	public String deleteBloodType(@RequestParam("blood_type_id") int blood_type_id) {
		int flag = 0;
		try {

			flag = service.deleteBloodType(blood_type_id);
			if (flag == 1) {
				return "deleted successfully";
			} else {
				throw new Exception("no record found");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "ERROR";
	}

	@GetMapping("/checkingblood")
	public String CheckingBloodType(@RequestParam("name") String name) {

		String s = null;
		try {
			s = service.CheckingBloodType(name);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return s;

	}

}
