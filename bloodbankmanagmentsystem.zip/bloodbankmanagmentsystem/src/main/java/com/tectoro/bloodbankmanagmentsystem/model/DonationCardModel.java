package com.tectoro.bloodbankmanagmentsystem.model;

public class DonationCardModel {

	private String donorCardId;
	private Donarmodel donars;

	public Donarmodel getDonars() {
		return donars;
	}

	public void setDonars(Donarmodel donars) {
		this.donars = donars;
	}

	public String getDonorCardId() {
		return donorCardId;
	}

	public void setDonorCardId(String donorCardId) {
		this.donorCardId = donorCardId;
	}

}
