package com.tectoro.bloodbankmanagmentsystem.domain;

public class Recipientdomain {
	int recipentID;
	String name;
	String contactNumber;
	Donardomain donars;
	BloodTypedomain bloodtypes;

	public int getRecipentID() {
		return recipentID;
	}

	public void setRecipentID(int recipentID) {
		this.recipentID = recipentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Donardomain getDonars() {
		return donars;
	}

	public void setDonars(Donardomain donars) {
		this.donars = donars;
	}

	public BloodTypedomain getBloodtypes() {
		return bloodtypes;
	}

	public void setBloodtypes(BloodTypedomain bloodtypes) {
		this.bloodtypes = bloodtypes;
	}

}
