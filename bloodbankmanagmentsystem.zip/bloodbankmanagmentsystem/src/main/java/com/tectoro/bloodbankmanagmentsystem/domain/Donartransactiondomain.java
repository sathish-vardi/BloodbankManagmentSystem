package com.tectoro.bloodbankmanagmentsystem.domain;

import java.sql.Date;

public class Donartransactiondomain {
	private int donorTransId;
	private String donationConfirmation;
	private String healthCondition;
	private Date date;
	private Donardomain donars;

	public int getDonorTransId() {
		return donorTransId;
	}

	public void setDonorTransId(int donorTransId) {
		this.donorTransId = donorTransId;
	}

	public String getDonationConfirmation() {
		return donationConfirmation;
	}

	public void setDonationConfirmation(String donationConfirmation) {
		this.donationConfirmation = donationConfirmation;
	}

	public String getHealthCondition() {
		return healthCondition;
	}

	public void setHealthCondition(String healthCondition) {
		this.healthCondition = healthCondition;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Donardomain getDonars() {
		return donars;
	}

	public void setDonars(Donardomain donars) {
		this.donars = donars;
	}

}
