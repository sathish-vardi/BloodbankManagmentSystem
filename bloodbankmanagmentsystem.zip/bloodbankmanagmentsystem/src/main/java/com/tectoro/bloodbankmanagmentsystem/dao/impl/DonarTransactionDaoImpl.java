package com.tectoro.bloodbankmanagmentsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.tectoro.bloodbankmanagmentsystem.dao.DonarTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donartransactiondomain;

@Repository
public class DonarTransactionDaoImpl implements DonarTransactionDao {

	@Autowired
	JdbcTemplate template;

	@Override
	public Donartransactiondomain addDonarTransaction(Donartransactiondomain domain) {
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert ");
			sqlQuery.append("into ");
			sqlQuery.append("donartransaction ");
			sqlQuery.append("(donor_id,");
			sqlQuery.append("donation_confirmation,");
			sqlQuery.append("health_condition,");
			sqlQuery.append("date)");
			sqlQuery.append("values(?,?,?,?)");

			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(sqlQuery.toString(), new String[] { "donor_trans_id" });
					ps.setInt(1, domain.getDonars().getDonor_id());
					ps.setString(2, domain.getDonationConfirmation());
					ps.setString(3, domain.getHealthCondition());
					ps.setDate(4, domain.getDate());
					return ps;
				}
			}, keyHolder);
			domain.setDonorTransId(keyHolder.getKey().intValue());
		} catch (Exception e) {
			throw e;
		}
		return null;
	}

	@Override
	public Donartransactiondomain getTransaction(int donorTransId) {
		Donartransactiondomain domain1 = new Donartransactiondomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("donartransaction ");
			sqlQuery.append("where ");
			sqlQuery.append("donor_trans_id =");
			sqlQuery.append(donorTransId);

			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<Donartransactiondomain>() {

				@Override
				public Donartransactiondomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					Donartransactiondomain res = new Donartransactiondomain();
					while (rs.next()) {
						res.setDonorTransId(rs.getInt("donor_trans_id"));
						res.setDonationConfirmation(rs.getString("donation_confirmation"));
						res.setHealthCondition(rs.getString("health_condition"));
						res.setDate(rs.getDate("date"));
						Donardomain domain = new Donardomain();
						domain.setDonor_id(rs.getInt("donor_id"));
						res.setDonars(domain);

					}
					return res;
				}
			});
		} catch (Exception e) {
			throw e;
		}
		return domain1;
	}

	@Override
	public Donartransactiondomain updateTransaction(Donartransactiondomain donor) {
		Donartransactiondomain domain1 = new Donartransactiondomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("update donartransaction set ");
			if (donor.getDonationConfirmation() != null) {
				sqlQuery.append("donation_confirmation='" + donor.getDonationConfirmation() + "', ");
			}
			if (donor.getHealthCondition() != null) {
				sqlQuery.append("health_condition='" + donor.getHealthCondition() + "', ");
			}
			if (donor.getDate() != null) {
				sqlQuery.append("date='" + donor.getDate() + "', ");
			}
			if (donor.getDonars().getDonor_id() != 0 && donor.getDonars().getDonor_id() > 0) {
				sqlQuery.append("donor_id=" + donor.getDonars().getDonor_id() + ", ");
			}
			StringBuilder builder = new StringBuilder();
			builder.append(sqlQuery.substring(0, sqlQuery.length() - 2));

			builder.append(" where ");
			builder.append("donor_trans_id=");
			builder.append(donor.getDonorTransId());

			template.batchUpdate(builder.toString());
		} catch (Exception e) {
			throw e;
		}
		return null;
	}

	@Override
	public int deleteTransaction(int donorid) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("donartransaction ");
			sqlQurery.append("where ");
			sqlQurery.append("donor_id=");
			sqlQurery.append(donorid);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public String CheckingDate(int donorid) {

		Donartransactiondomain domain1 = null;
		String s = null;
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("donartransaction ");
			sqlQuery.append("where ");
			sqlQuery.append("donor_id =");
			sqlQuery.append(donorid);

			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<Donartransactiondomain>() {

				@Override
				public Donartransactiondomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					Donartransactiondomain res = new Donartransactiondomain();
					while (rs.next()) {
						res.setDonorTransId(rs.getInt("donor_trans_id"));
						res.setDonationConfirmation(rs.getString("donation_confirmation"));
						res.setHealthCondition(rs.getString("health_condition"));
						res.setDate(rs.getDate("date"));
						Donardomain domain = new Donardomain();
						domain.setDonor_id(rs.getInt("donor_id"));
						res.setDonars(domain);

					}
					return res;
				}
			});
			if (domain1.getDonars().getDonor_id() > 0 && domain1.getDate() != null) {
				s = String.valueOf(domain1.getDate());
				return s;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	@Override
	public String CheckingEligibty(int donor_trans_id) {
		Donartransactiondomain domain1 = null;
		String s = null;
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("donartransaction ");
			sqlQuery.append("where ");
			sqlQuery.append("donor_trans_id =");
			sqlQuery.append(donor_trans_id);

			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<Donartransactiondomain>() {

				@Override
				public Donartransactiondomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					Donartransactiondomain res = new Donartransactiondomain();
					while (rs.next()) {
						res.setDonorTransId(rs.getInt("donor_trans_id"));
						res.setDonationConfirmation(rs.getString("donation_confirmation"));
						res.setHealthCondition(rs.getString("health_condition"));
						res.setDate(rs.getDate("date"));
						Donardomain domain = new Donardomain();
						domain.setDonor_id(rs.getInt("donor_id"));
						res.setDonars(domain);

					}
					return res;
				}
			});
			if (domain1.getDonars().getDonor_id() > 0 && domain1.getDate() != null) {
				s = String.valueOf(domain1.getDate());
				return s;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
