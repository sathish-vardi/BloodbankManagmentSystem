package com.tectoro.bloodbankmanagmentsystem.dao;

import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;

public interface BloodTypeDao {
	
	public BloodTypedomain addBloodType(BloodTypedomain bloodtype);

	public BloodTypedomain updateBloodType(BloodTypedomain domain);

	public BloodTypedomain getBloodType(Integer blood_type_id);

	public int deleteBloodType(Integer blood_type_id);

	public String CheckBloodType(String name);

}
