package com.tectoro.bloodbankmanagmentsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodbankmanagmentsystemApplication {

	public static void main(String[] args) {

		SpringApplication.run(BloodbankmanagmentsystemApplication.class, args);
		System.out.println("done");
	}

}
