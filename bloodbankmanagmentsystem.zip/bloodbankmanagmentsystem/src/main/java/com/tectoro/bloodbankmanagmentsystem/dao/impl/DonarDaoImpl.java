package com.tectoro.bloodbankmanagmentsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.tectoro.bloodbankmanagmentsystem.dao.DonarDao;
import com.tectoro.bloodbankmanagmentsystem.dao.DonarTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.dao.DonationCardDao;
import com.tectoro.bloodbankmanagmentsystem.dao.RecipientDao;
import com.tectoro.bloodbankmanagmentsystem.dao.RecipientTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;

@Repository
public class DonarDaoImpl implements DonarDao {

	@Autowired
	private JdbcTemplate template;
	@Autowired
	private RecipientDao dao;
	@Autowired
	private DonationCardDao dao1;
	@Autowired
	private DonarTransactionDao dao2;
	@Autowired
	private RecipientTransactionDao reciTrapdao;

	@Override
	public Donardomain addDonar(Donardomain donarmodel) {
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert ");
			sqlQuery.append("into ");
			sqlQuery.append("donar ");
			sqlQuery.append("(blood_type_id,");
			sqlQuery.append("name,");
			sqlQuery.append("contact_number,");
			sqlQuery.append("donor_card_id)");
			sqlQuery.append("values(?,?,?,?)");

			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(sqlQuery.toString(), new String[] { "donor_id" });
					ps.setInt(1, donarmodel.getBloodtype().getBlood_type_id());
					ps.setString(2, donarmodel.getName());
					ps.setLong(3, donarmodel.getContact_number());
					ps.setInt(4, donarmodel.getDonor_card_id());
					return ps;
				}
			}, keyHolder);
			donarmodel.setDonor_id(keyHolder.getKey().intValue());

		} catch (Exception e) {
			throw e;
		}

		return null;
	}

	@Override
	public Donardomain getDonar(Integer blood_type_id) {
		Donardomain domain1 = new Donardomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("d.*,b.* from ");
			sqlQuery.append("donar d inner join bloodtype b");
			sqlQuery.append(" on ");
			sqlQuery.append("d.blood_type_id ="+blood_type_id);
			sqlQuery.append(" and b.blood_type_id="+blood_type_id);
			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<Donardomain>() {

				@Override
				public Donardomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					Donardomain res = new Donardomain();
					while (rs.next()) {
						res.setDonor_id(rs.getInt("donor_id"));
						res.setName(rs.getString("name"));
						res.setContact_number(rs.getLong("contact_number"));
						res.setDonor_card_id(rs.getInt("donor_card_id"));
						BloodTypedomain domain = new BloodTypedomain();
						domain.setBlood_type_id(rs.getInt("blood_type_id"));
						res.setBloodtype(domain);
						domain.setName(rs.getString("name"));
					}
					return res;
				}
			});
		} catch (Exception e) {
			throw e;
		}
		return domain1;
	}

	public Donardomain updateDonar(Donardomain donar) {

		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("update donar set ");

			if (donar.getName() != null) {
				sqlQuery.append("name='" + donar.getName() + "', ");
			}
			if (donar.getBloodtype().getBlood_type_id() > 0) {
				sqlQuery.append("blood_type_id=" + donar.getBloodtype().getBlood_type_id() + ", ");
			}
			if (donar.getContact_number() > 0) {
				sqlQuery.append("contact_number=" + donar.getContact_number() + ", ");
			}
			if (donar.getDonor_card_id() > 0) {
				sqlQuery.append("donor_card_id=" + donar.getDonor_card_id() + ", ");
			}
			StringBuilder builder = new StringBuilder();
			builder.append(sqlQuery.substring(0, sqlQuery.length() - 2));

			builder.append(" where ");
			builder.append("donor_id=");
			builder.append(donar.getDonor_id());

			template.batchUpdate(builder.toString());

		} catch (Exception e) {
			throw e;
		}
		return null;
	}

	@Override
	public int deleteDonar(int bloodtypeid) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("donar ");
			sqlQurery.append("where ");
			sqlQurery.append("blood_type_id=");
			sqlQurery.append(bloodtypeid);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int deleteDonarByDonarID(int donor_id) {
		List<Integer> list=new ArrayList<>();	
		int flag = 0;
		int donarcardId = 0;
		int recipientId = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("donar ");
			sqlQurery.append("where ");
			sqlQurery.append("donor_id=");
			sqlQurery.append(donor_id);

			
			list = dao.deleteRecipentByDonarId(donor_id);
			
			
			flag = dao2.deleteTransaction(donor_id);
			if (flag == 1) {
				donarcardId = dao1.deleteDonationCardByDonarID(donor_id);
				if (flag == 1 && donarcardId > 0) {
					list = dao.deleteRecipentByDonarId(donor_id);
				}
				if (flag == 1 && recipientId > 0 && donarcardId > 0) {
					reciTrapdao.deleteTransactionById(donarcardId, recipientId);
					flag += dao1.deleteDonationCard(donor_id);
					flag += dao.deleteRecipent(donor_id);

				}
				if (flag == 3) {
					flag = template.update(sqlQurery.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
