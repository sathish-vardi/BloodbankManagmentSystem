package com.tectoro.bloodbankmanagmentsystem.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tectoro.bloodbankmanagmentsystem.model.RecipientTransactionModel;
import com.tectoro.bloodbankmanagmentsystem.service.RecipientTransactionService;

@RestController
@RequestMapping("/recipienttransaction")
public class RecipientTransactionController {

	@Autowired
	private RecipientTransactionService service;

	@PostMapping("/addrecipenttransaction")
	public String addRecipentTransaction(@RequestBody RecipientTransactionModel transaction) {
		try {
			service.addTransaction(transaction);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return "sucessfully added";
	}

	@GetMapping("/getrecipient")
	public RecipientTransactionModel getRecipientTransaction(@RequestParam("recipientTransId") int recipientTransId) {
		RecipientTransactionModel model = null;
		try {
			model = service.getRecipient(recipientTransId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}

	@PutMapping("/updaterecipent")
	public RecipientTransactionModel updaterecipientTransaction(@RequestBody RecipientTransactionModel model) {
		RecipientTransactionModel model1 = null;
		try {
			model = service.updaterecipentTransaction(model);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model1;
	}

	@DeleteMapping("deleteTransaction")
	public String deleteTransaction(@RequestParam("recipient_trans_id") int recipient_trans_id) {
		
		try {
			service.deleteTransaction(recipient_trans_id);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	@GetMapping("/checkingdate")
	public String CheckingDate(@RequestParam("recipientTransId") int recipientTransId) {
		String s=null;
		try {
			s=service.CheckingDate(recipientTransId);
		} catch (Exception e) {
		System.out.println(e.getMessage());
		}
		return s;
	}
	
}
