package com.tectoro.bloodbankmanagmentsystem.model;

public class RecipientModel {
	String recipentID;
	String name;
	String contactNumber;
	Donarmodel donars;
	BloodTypemodel bloodtypes;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getRecipentID() {
		return recipentID;
	}

	public void setRecipentID(String recipentID) {
		this.recipentID = recipentID;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Donarmodel getDonars() {
		return donars;
	}

	public void setDonars(Donarmodel donars) {
		this.donars = donars;
	}

	public BloodTypemodel getBloodtypes() {
		return bloodtypes;
	}

	public void setBloodtypes(BloodTypemodel bloodtypes) {
		this.bloodtypes = bloodtypes;
	}

}
