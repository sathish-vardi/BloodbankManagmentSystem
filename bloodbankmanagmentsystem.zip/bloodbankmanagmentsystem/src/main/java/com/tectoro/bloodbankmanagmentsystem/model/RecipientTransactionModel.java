package com.tectoro.bloodbankmanagmentsystem.model;

public class RecipientTransactionModel {

	String recipientTransId;
	RecipientModel recepients;
	String recipientRequest;
	String date;
	BloodTypemodel bloodtypes;
	DonationCardModel donationcards;

	public String getRecipientTransId() {
		return recipientTransId;
	}

	public void setRecipientTransId(String recipientTransId) {
		this.recipientTransId = recipientTransId;
	}

	public RecipientModel getRecepients() {
		return recepients;
	}

	public void setRecepients(RecipientModel recepients) {
		this.recepients = recepients;
	}

	public String getRecipientRequest() {
		return recipientRequest;
	}

	public void setRecipientRequest(String recipientRequest) {
		this.recipientRequest = recipientRequest;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public BloodTypemodel getBloodtypes() {
		return bloodtypes;
	}

	public void setBloodtypes(BloodTypemodel bloodtypes) {
		this.bloodtypes = bloodtypes;
	}

	public DonationCardModel getDonationcards() {
		return donationcards;
	}

	public void setDonationcards(DonationCardModel donationcards) {
		this.donationcards = donationcards;
	}

}
