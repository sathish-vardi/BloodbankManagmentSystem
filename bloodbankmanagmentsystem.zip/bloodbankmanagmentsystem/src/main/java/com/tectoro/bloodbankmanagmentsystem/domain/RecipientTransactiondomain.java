package com.tectoro.bloodbankmanagmentsystem.domain;

import java.sql.Date;

public class RecipientTransactiondomain {

	int recipientTransId;
	String recipientRequest;
	Date date;
	BloodTypedomain bloodtypes;
	DonationCarddomain donationcards;
	Recipientdomain recepients;

	public int getRecipientTransId() {
		return recipientTransId;
	}

	public void setRecipientTransId(int recipientTransId) {
		this.recipientTransId = recipientTransId;
	}

	public String getRecipientRequest() {
		return recipientRequest;
	}

	public void setRecipientRequest(String recipientRequest) {
		this.recipientRequest = recipientRequest;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public BloodTypedomain getBloodtypes() {
		return bloodtypes;
	}

	public void setBloodtypes(BloodTypedomain bloodtypes) {
		this.bloodtypes = bloodtypes;
	}

	public DonationCarddomain getDonationcards() {
		return donationcards;
	}

	public void setDonationcards(DonationCarddomain donationcards) {
		this.donationcards = donationcards;
	}

	public Recipientdomain getRecepients() {
		return recepients;
	}

	public void setRecepients(Recipientdomain recepients) {
		this.recepients = recepients;
	}

}
