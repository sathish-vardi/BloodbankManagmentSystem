package com.tectoro.bloodbankmanagmentsystem.model;

public class DonartransactionModel {
	String donorTransId;
	String donationConfirmation;
	String healthCondition;
	String date;
	Donarmodel donars;
	public String getDonorTransId() {
		return donorTransId;
	}
	public void setDonorTransId(String donorTransId) {
		this.donorTransId = donorTransId;
	}
	public String getDonationConfirmation() {
		return donationConfirmation;
	}
	public void setDonationConfirmation(String donationConfirmation) {
		this.donationConfirmation = donationConfirmation;
	}
	public String getHealthCondition() {
		return healthCondition;
	}
	public void setHealthCondition(String healthCondition) {
		this.healthCondition = healthCondition;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Donarmodel getDonars() {
		return donars;
	}
	public void setDonars(Donarmodel donars) {
		this.donars = donars;
	}


}
