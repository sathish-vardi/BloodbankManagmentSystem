package com.tectoro.bloodbankmanagmentsystem.dao;

import com.tectoro.bloodbankmanagmentsystem.domain.Donartransactiondomain;

public interface DonarTransactionDao {

	public Donartransactiondomain addDonarTransaction(Donartransactiondomain domain);

	public Donartransactiondomain getTransaction(int donorTransId);

	public Donartransactiondomain updateTransaction(Donartransactiondomain donorTransId);

	public int deleteTransaction(int donorid);

	public String CheckingDate(int donorid);

	public String CheckingEligibty(int donorid);

	

}
