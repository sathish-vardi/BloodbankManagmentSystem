package com.tectoro.bloodbankmanagmentsystem.service.impl;

import java.sql.Date;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tectoro.bloodbankmanagmentsystem.dao.DonarTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donartransactiondomain;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;
import com.tectoro.bloodbankmanagmentsystem.model.DonartransactionModel;
import com.tectoro.bloodbankmanagmentsystem.service.DonarTransactionService;

@Service
public class DonarTransactionServiceImpl implements DonarTransactionService {

	@Autowired
	DonarTransactionDao dao;

	@Override
	public DonartransactionModel addDonarTransaction(DonartransactionModel transaction) {

		Donartransactiondomain domain = new Donartransactiondomain();
		domain.setDonationConfirmation(transaction.getDonationConfirmation());
		domain.setHealthCondition(transaction.getHealthCondition());
		domain.setDate(Date.valueOf(transaction.getDate()));
		Donardomain domian1 = new Donardomain();
		domian1.setDonor_id(Integer.parseInt(transaction.getDonars().getDonor_id()));
		domain.setDonars(domian1);
		dao.addDonarTransaction(domain);

		DonartransactionModel model = new DonartransactionModel();
		model.setDonationConfirmation(domain.getDonationConfirmation());
		model.setHealthCondition(domain.getHealthCondition());
		model.setDate(String.valueOf(domain.getDate()));
		model.setDonorTransId(String.valueOf(domain.getDonorTransId()));

		Donarmodel model1 = new Donarmodel();
		model1.setDonor_id(String.valueOf(domain.getDonars().getDonor_id()));
		model.setDonars(model1);

		return model;
	}

	@Override
	public DonartransactionModel getTransaction(int donorTransId) {
		Donartransactiondomain domain = new Donartransactiondomain();
		domain = dao.getTransaction(donorTransId);

		DonartransactionModel model = new DonartransactionModel();
		model.setDonorTransId(String.valueOf(domain.getDonorTransId()));
		model.setDonationConfirmation(domain.getDonationConfirmation());
		model.setHealthCondition(domain.getHealthCondition());
		model.setDate(String.valueOf(domain.getDate()));

		Donarmodel model2 = new Donarmodel();
		model2.setDonor_id(String.valueOf(domain.getDonars().getDonor_id()));
		model.setDonars(model2);

		return model;
	}

	@Override
	public DonartransactionModel updatetransaction(DonartransactionModel transation) {
		Donartransactiondomain domain = new Donartransactiondomain();
		domain.setDonorTransId(Integer.parseInt(transation.getDonorTransId()));
		if (transation.getDonationConfirmation() != null) {
			domain.setDonationConfirmation(transation.getDonationConfirmation());
		}
		if (transation.getHealthCondition() != null) {
			domain.setHealthCondition(transation.getHealthCondition());
		}
		if (transation.getDate() != null) {
			domain.setDate(Date.valueOf(transation.getDate()));
		}
		if (transation.getDonars().getDonor_id() != null) {
			Donardomain domain1 = new Donardomain();
			domain1.setDonor_id(Integer.parseInt(transation.getDonars().getDonor_id()));
			domain.setDonars(domain1);
		}
		dao.updateTransaction(domain);

		DonartransactionModel model = new DonartransactionModel();
		model.setDonorTransId(String.valueOf(domain.getDonorTransId()));
		model.setDonationConfirmation(domain.getDonationConfirmation());
		model.setHealthCondition(domain.getHealthCondition());
		model.setDate(String.valueOf(domain.getDate()));
		Donarmodel mode1 = new Donarmodel();
		mode1.setDonor_id(String.valueOf(domain.getDonars().getDonor_id()));
		model.setDonars(mode1);

		return model;
	}

	@Override
	public int deleteDonartransaction(int donorid) {

		return dao.deleteTransaction(donorid);
	}

	@Override
	public String CheckingDate(int donorid) {

		return dao.CheckingDate(donorid);
	}

	@Override
	public String CheckingEligibty(int donor_trans_id) {
		String s1 = null;
		String s = dao.CheckingEligibty(donor_trans_id);

		SimpleDateFormat obj = new SimpleDateFormat("yyyy-MM-dd");
		try {
			java.util.Date date = obj.parse(s);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDateTime now = LocalDateTime.now();

			java.util.Date date1 = obj.parse(dtf.format(now));
			long i = date1.getTime() - date.getTime();

			long days = (i / (1000 * 60 * 60 * 24)) % 365;

			// System.out.println(days);

			if (days >= 90) {
				s1 = "he is eligible for donating the blood";
				return s1;
			} else {
				s1 = "he is not eligible for donationg the blood because he denoted lessthan90 days";
				return s1;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "error";
	}

}
