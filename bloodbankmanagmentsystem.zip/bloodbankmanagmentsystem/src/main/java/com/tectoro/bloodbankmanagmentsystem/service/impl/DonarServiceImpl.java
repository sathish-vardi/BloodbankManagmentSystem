package com.tectoro.bloodbankmanagmentsystem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tectoro.bloodbankmanagmentsystem.dao.DonarDao;
import com.tectoro.bloodbankmanagmentsystem.dao.impl.DonarDaoImpl;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;
import com.tectoro.bloodbankmanagmentsystem.service.DonarService;

@Service
public class DonarServiceImpl implements DonarService {

	@Autowired
	private DonarDao donardao;

	@Override
	public Donarmodel addDonar(Donarmodel donarmodel) {

		Donardomain domain = new Donardomain();
		domain.setName(donarmodel.getName());
		domain.setContact_number(Long.parseLong(donarmodel.getContact_number()));
		domain.setDonor_card_id(Integer.parseInt(donarmodel.getDonor_card_id()));

		BloodTypedomain domain1 = new BloodTypedomain();
		domain1.setBlood_type_id(Integer.parseInt(donarmodel.getBloodtype().getBlood_type_id()));

		domain.setBloodtype(domain1);
		donardao.addDonar(domain);

		BloodTypemodel model = new BloodTypemodel();
		model.setBlood_type_id(String.valueOf(domain.getBloodtype().getBlood_type_id()));
		donarmodel.setBloodtype(model);
		Donarmodel donarmodel1 = new Donarmodel();
		donarmodel1.setName(domain.getName());
		donarmodel1.setContact_number(String.valueOf(domain.getContact_number()));
		donarmodel1.setDonor_card_id(String.valueOf(domain.getDonor_card_id()));
		donarmodel1.setDonor_id(String.valueOf(domain.getDonor_id()));

		return donarmodel1;
	}

	@Override
	public Donarmodel getDonar(Integer donor_id) {

		Donardomain domain = new Donardomain();
		domain = donardao.getDonar(donor_id);

		Donarmodel model = new Donarmodel();
		model.setName(domain.getName());
		model.setDonor_id(String.valueOf(domain.getDonor_id()));
		model.setContact_number(String.valueOf(domain.getContact_number()));
		model.setDonor_card_id(String.valueOf(domain.getDonor_card_id()));

		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(domain.getBloodtype().getBlood_type_id()));
		model.setBloodtype(bloodTypemodel);
		bloodTypemodel.setName(domain.getName());
		model.setBloodtype(bloodTypemodel);

		return model;
	}

	@Override
	public Donarmodel updateDonar(Donarmodel donar) {

		Donardomain domain = new Donardomain();
		domain.setDonor_id(Integer.parseInt(donar.getDonor_id()));
		if (donar.getName() != null) {
			domain.setName(donar.getName());
		}
		if (donar.getContact_number() != null) {
			domain.setContact_number(Long.parseLong(donar.getContact_number()));
		}
		if (donar.getDonor_card_id() != null) {
			domain.setDonor_card_id(Integer.parseInt(donar.getDonor_card_id()));
		}
		if (donar.getBloodtype().getBlood_type_id() != null) {
			BloodTypedomain domain1 = new BloodTypedomain();
			domain1.setBlood_type_id(Integer.parseInt(donar.getBloodtype().getBlood_type_id()));
			domain.setBloodtype(domain1);
		}
		donardao.updateDonar(domain);

		Donarmodel model = new Donarmodel();
		model.setName(domain.getName());
		model.setContact_number(String.valueOf(domain.getContact_number()));
		model.setDonor_card_id(String.valueOf(domain.getDonor_card_id()));
		model.setDonor_id(String.valueOf(domain.getDonor_id()));

		BloodTypemodel bloodTypemodel = new BloodTypemodel();
		bloodTypemodel.setBlood_type_id(String.valueOf(domain.getBloodtype().getBlood_type_id()));
		model.setBloodtype(bloodTypemodel);

		return model;
	}

	@Override
	public String deleteDonarByDonarID(int donor_id) throws Exception {

		int flag = 0;
		try {
			
			if (donor_id != 0) {
				flag = donardao.deleteDonarByDonarID(donor_id);
			}
			if (flag == 1) {
				return "deleted sucessfully";
			} else {
				throw new Exception("id not found");
			}
		} catch (Exception e) {

			throw e;
		}
	}

}
