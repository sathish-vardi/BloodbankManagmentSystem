package com.tectoro.bloodbankmanagmentsystem.domain;

public class Donardomain {
	
	private int donor_id;
	private String name;
	private long contact_number;
	private int donor_card_id;
	private BloodTypedomain bloodtype;
	
	public int getDonor_id() {
		return donor_id;
	}
	public void setDonor_id(int donor_id) {
		this.donor_id = donor_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
	
	public int getDonor_card_id() {
		return donor_card_id;
	}
	public void setDonor_card_id(int donor_card_id) {
		this.donor_card_id = donor_card_id;
	}
	public BloodTypedomain getBloodtype() {
		return bloodtype;
	}
	public void setBloodtype(BloodTypedomain bloodtype) {
		this.bloodtype = bloodtype;
	}
	
	

}
