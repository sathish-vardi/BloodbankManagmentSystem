package com.tectoro.bloodbankmanagmentsystem.service;

import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;

public interface BloodTypeService {
	
	public BloodTypemodel addBloodType(BloodTypemodel inputmodel);

	public BloodTypemodel updateBloodType(BloodTypemodel bloodtype);

	BloodTypemodel getBloodType(Integer blood_type_id) throws Exception;

	public int deleteBloodType(int blood_type_id);

	public String CheckingBloodType(String string);

}
