package com.tectoro.bloodbankmanagmentsystem.service;

import com.tectoro.bloodbankmanagmentsystem.model.DonartransactionModel;

public interface DonarTransactionService {

	public DonartransactionModel addDonarTransaction(DonartransactionModel transaction);

	public DonartransactionModel getTransaction(int donorTransId);

	public DonartransactionModel updatetransaction(DonartransactionModel transation);

	public int deleteDonartransaction(int donorid);

	public String CheckingDate(int donorid);

	public String CheckingEligibty(int donorid);

}
