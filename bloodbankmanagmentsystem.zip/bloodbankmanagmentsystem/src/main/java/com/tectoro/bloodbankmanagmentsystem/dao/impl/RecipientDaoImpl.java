package com.tectoro.bloodbankmanagmentsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.tectoro.bloodbankmanagmentsystem.dao.RecipientDao;
import com.tectoro.bloodbankmanagmentsystem.dao.RecipientTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Recipientdomain;

@Repository
public class RecipientDaoImpl implements RecipientDao {

	@Autowired
	JdbcTemplate template;

	@Autowired
	RecipientTransactionDao dao;

	@Override
	public Recipientdomain addrecipent(Recipientdomain recipent) {
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert ");
			sqlQuery.append("into ");
			sqlQuery.append("recipent ");
			sqlQuery.append("(donor_id,");
			sqlQuery.append("blood_type_id,");
			sqlQuery.append("name,");
			sqlQuery.append("contact_number)");
			sqlQuery.append("values(?,?,?,?)");
			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(sqlQuery.toString(), new String[] { "recipent_id" });
					ps.setInt(1, recipent.getDonars().getDonor_id());
					ps.setInt(2, recipent.getBloodtypes().getBlood_type_id());
					ps.setString(3, recipent.getName());
					ps.setString(4, recipent.getContactNumber());
					return ps;
				}
			}, keyHolder);
			recipent.setRecipentID(keyHolder.getKey().intValue());
		} catch (Exception e) {
			throw e;
		}
		return recipent;
	}

	@Override
	public Recipientdomain getRecipent(int recipentID) {
		Recipientdomain domain = new Recipientdomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("recipent");
			sqlQuery.append(" where ");
			sqlQuery.append("recipent_id=");
			sqlQuery.append(recipentID);
			domain = template.query(sqlQuery.toString(), new ResultSetExtractor<Recipientdomain>() {

				@Override
				public Recipientdomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					Recipientdomain res = new Recipientdomain();
					while (rs.next()) {
						res.setRecipentID(rs.getInt("recipent_id"));
						res.setContactNumber(rs.getString("contact_number"));
						res.setName(rs.getString("name"));
						BloodTypedomain bloodTypedomain = new BloodTypedomain();
						bloodTypedomain.setBlood_type_id(rs.getInt("blood_type_id"));
						res.setBloodtypes(bloodTypedomain);
						Donardomain donardomain = new Donardomain();
						donardomain.setDonor_id(rs.getInt("donor_id"));
						res.setDonars(donardomain);
					}
					return res;
				}
			});
		} catch (Exception e) {
			throw e;
		}
		return domain;
	}

	@Override
	public Recipientdomain updateRecipent(Recipientdomain recipientdomain) {
		Recipientdomain domain = new Recipientdomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("update recipent set ");
			if (recipientdomain.getContactNumber() != null) {
				sqlQuery.append("contact_number='" + recipientdomain.getContactNumber() + "', ");
			}
			if (recipientdomain.getName() != null) {
				sqlQuery.append("name='" + recipientdomain.getName() + "', ");
			}
			if (recipientdomain.getBloodtypes().getBlood_type_id() > 0) {
				sqlQuery.append("blood_type_id=" + recipientdomain.getBloodtypes().getBlood_type_id() + ", ");
			}
			if (recipientdomain.getDonars().getDonor_id() != 0 && recipientdomain.getDonars().getDonor_id() > 0) {
				sqlQuery.append("donor_id=" + recipientdomain.getDonars().getDonor_id() + ", ");
			}
			StringBuilder builder = new StringBuilder();
			builder.append(sqlQuery.substring(0, sqlQuery.length() - 2));

			builder.append(" where ");
			builder.append("recipent_id=");
			builder.append(recipientdomain.getRecipentID());

			template.batchUpdate(builder.toString());
		} catch (Exception e) {
			throw e;
		}
		return null;
	}

	@Override
	public int deleteRecipent(int donor_id) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("recipent ");
			sqlQurery.append("where ");
			sqlQurery.append("donor_id=");
			sqlQurery.append(donor_id);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public List<Integer> deleteRecipentByDonarId(int donor_id) {
		List<Integer> list=new ArrayList<>();
		int flag = 0;
		int recipientId = 0;
		try {
			StringBuilder sqlQurery1 = new StringBuilder();
			sqlQurery1.append("select ");
			sqlQurery1.append("* from ");
			sqlQurery1.append("recipent ");
			sqlQurery1.append("where ");
			sqlQurery1.append("donor_id =");
			sqlQurery1.append(donor_id);
			Recipientdomain recipientdomain = new Recipientdomain();
			recipientdomain = template.query(sqlQurery1.toString(), new ResultSetExtractor<Recipientdomain>() {

			
				@Override
				public Recipientdomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					Recipientdomain res = new Recipientdomain();
					while (rs.next()) {

						
						
						res.setRecipentID(rs.getInt("recipent_id"));
//						res.setContactNumber(rs.getString("contact_number"));
//						res.setName(rs.getString("name"));
//						BloodTypedomain bloodTypedomain = new BloodTypedomain();
//						bloodTypedomain.setBlood_type_id(rs.getInt("blood_type_id"));
//						res.setBloodtypes(bloodTypedomain);
//						Donardomain donardomain = new Donardomain();
//						donardomain.setDonor_id(rs.getInt("donor_id"));
//						res.setDonars(donardomain);

					}
					return res;
				}
			});

			if (recipientdomain != null) {
				recipientId = recipientdomain.getRecipentID();
				return list;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
