package com.tectoro.bloodbankmanagmentsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tectoro.bloodbankmanagmentsystem.model.DonationCardModel;
import com.tectoro.bloodbankmanagmentsystem.service.DonationCardService;

@RestController
@RequestMapping("/donationcard")
public class DonationCardController {

	@Autowired
	private DonationCardService service;

	@PostMapping("/adddonation")
	public DonationCardModel addDonationCard(@RequestBody DonationCardModel cardModel) {

		DonationCardModel model = null;
		try {
			model = service.addDonationCard(cardModel);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}
	
	@GetMapping("/getdonation")
	public DonationCardModel getDonation(@RequestParam("donorCardId") int donorCardId) {
		DonationCardModel model=null;
		try {
			model= service.getDonation(donorCardId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}

}
