package com.tectoro.bloodbankmanagmentsystem.model;

public class Donarmodel {

	private String donor_id;
	String name;
	String contact_number;
	String donor_card_id;
	BloodTypemodel bloodtype;

	public String getDonor_id() {
		return donor_id;
	}

	public void setDonor_id(String donor_id) {
		this.donor_id = donor_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public String getDonor_card_id() {
		return donor_card_id;
	}

	public void setDonor_card_id(String donor_card_id) {
		this.donor_card_id = donor_card_id;
	}

	public BloodTypemodel getBloodtype() {
		return bloodtype;
	}

	public void setBloodtype(BloodTypemodel bloodtype) {
		this.bloodtype = bloodtype;
	}

}
