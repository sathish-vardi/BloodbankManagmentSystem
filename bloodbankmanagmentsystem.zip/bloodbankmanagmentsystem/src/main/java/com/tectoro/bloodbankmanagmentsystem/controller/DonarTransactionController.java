package com.tectoro.bloodbankmanagmentsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tectoro.bloodbankmanagmentsystem.model.DonartransactionModel;
import com.tectoro.bloodbankmanagmentsystem.service.DonarTransactionService;

@RestController
@RequestMapping("/donartransaction")
public class DonarTransactionController {

	@Autowired
	private DonarTransactionService service;

	@PostMapping("/addtransaction")
	public DonartransactionModel addDonarTransaction(@RequestBody DonartransactionModel transaction) {
		DonartransactionModel model = null;
		try {
			model = service.addDonarTransaction(transaction);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return model;
	}

	@GetMapping("/getTransaction")
	public DonartransactionModel getTransaction(@RequestParam("donorTransId") int donorTransId) {
		DonartransactionModel model = null;
		try {
			model = service.getTransaction(donorTransId);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}

	@PutMapping("/updatetransaction")
	public DonartransactionModel updateTansaction(@RequestBody DonartransactionModel transation) {
		DonartransactionModel model = null;
		try {
			model = service.updatetransaction(transation);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return model;
	}

	@DeleteMapping("/deletetransaction")
	public String deletetransaction(@RequestParam("donorid") int donorid) {
		try {
			service.deleteDonartransaction(donorid);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	@GetMapping("/checkingdate")
	public String CheckingDate(@RequestParam("donorid") int donorid) {
		String s = null;
		try {
			s = service.CheckingDate(donorid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	@GetMapping("/checkingeligibity")
	public String CheckingEligibty(@RequestParam("donorid") int donor_trans_id) {
		String s = null;
		try {
			s = service.CheckingEligibty(donor_trans_id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
}
