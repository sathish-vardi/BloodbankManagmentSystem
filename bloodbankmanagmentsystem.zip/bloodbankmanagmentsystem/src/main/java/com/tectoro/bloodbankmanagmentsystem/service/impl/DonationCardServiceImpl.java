package com.tectoro.bloodbankmanagmentsystem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tectoro.bloodbankmanagmentsystem.dao.DonationCardDao;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.DonationCarddomain;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;
import com.tectoro.bloodbankmanagmentsystem.model.DonationCardModel;
import com.tectoro.bloodbankmanagmentsystem.service.DonationCardService;

@Service
public class DonationCardServiceImpl implements DonationCardService {

	@Autowired
	private DonationCardDao dao;

	@Override
	public DonationCardModel addDonationCard(DonationCardModel cardModel) {
		DonationCarddomain carddomain = new DonationCarddomain();
		carddomain.setDonorCardId(Integer.parseInt(cardModel.getDonorCardId()));
		Donardomain domain = new Donardomain();
		domain.setDonor_id(Integer.parseInt(cardModel.getDonars().getDonor_id()));
		carddomain.setDonars(domain);
		carddomain = dao.getaddDonationCard(carddomain);

		DonationCardModel cardModel2 = new DonationCardModel();
		cardModel2.setDonorCardId(String.valueOf(carddomain.getDonorCardId()));
		Donarmodel donarmodel = new Donarmodel();
		donarmodel.setDonor_id(String.valueOf(carddomain.getDonars().getDonor_id()));

		cardModel2.setDonars(donarmodel);

		return cardModel2;
	}

	@Override
	public DonationCardModel getDonation(int donorCardId) {
		DonationCarddomain cardModel = new DonationCarddomain();
		cardModel = dao.getDonation(donorCardId);

		DonationCardModel cardModel2 = new DonationCardModel();
		cardModel2.setDonorCardId(String.valueOf(cardModel.getDonorCardId()));
		Donarmodel donarmodel = new Donarmodel();
		donarmodel.setDonor_id(String.valueOf(cardModel.getDonars().getDonor_id()));
		cardModel2.setDonars(donarmodel);

		return cardModel2;
	}

}
