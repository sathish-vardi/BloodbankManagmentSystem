package com.tectoro.bloodbankmanagmentsystem.controller;

import java.nio.file.Path;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.model.Donarmodel;
import com.tectoro.bloodbankmanagmentsystem.service.DonarService;

@RestController
@RequestMapping("/donar")
public class DonarController {

	@Autowired
	private DonarService service;

	@PostMapping("/adddonar")
	public Donarmodel addDonar(@RequestBody Donarmodel donar) {
		Donarmodel model = null;
		try {
			model = service.addDonar(donar);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}

	@GetMapping("/getdonar")
	public Donarmodel getDonar(@RequestParam("blood_type_id") int blood_type_id) {
		Donarmodel model = null;
		try {
			model = service.getDonar(blood_type_id);
		} catch (Exception e) {
			throw e;
		}

		return model;
	}

	@PutMapping("/updatedonar")
	public Donarmodel updateDonar(@RequestBody Donarmodel donar) {

		Donarmodel model = null;
		try {
			model = service.updateDonar(donar);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}

	@DeleteMapping("/deleteDonar")
	public String deleteDonarByDonarID(@RequestParam("donor_id") int donor_id) {

		String flag = null;
		try {
			flag = service.deleteDonarByDonarID(donor_id);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return flag;
	}

}
