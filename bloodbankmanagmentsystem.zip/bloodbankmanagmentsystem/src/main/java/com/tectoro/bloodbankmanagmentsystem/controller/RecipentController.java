package com.tectoro.bloodbankmanagmentsystem.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tectoro.bloodbankmanagmentsystem.model.RecipientModel;
import com.tectoro.bloodbankmanagmentsystem.service.RecipentService;

@RestController
@RequestMapping("/recipentent")
public class RecipentController {

	@Autowired
	RecipentService service;

	@PostMapping("/addrecipent")
	public RecipientModel addRecipent(@RequestBody RecipientModel recipent) {
		RecipientModel model = null;
		try {
			model = service.addrecipent(recipent);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}

	@GetMapping("/getrecipent")
	public RecipientModel getRecipent(@RequestParam("recipentID") int recipentID) {
		RecipientModel model = null;
		try {
			model = service.getRecipent(recipentID);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return model;
	}

	@PutMapping("/updaterecipent")
	public RecipientModel updateRecipent(@RequestBody RecipientModel recipientModel) {
		RecipientModel model = null;
		try {
			model = service.updaterecipent(recipientModel);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return model;
	}
	
	@DeleteMapping("/deleterecipient")
	public String deleteRecipent(@RequestParam("bloodtypeid") int bloodtypeid) {
		try {
			service.deleteRecipent(bloodtypeid);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
