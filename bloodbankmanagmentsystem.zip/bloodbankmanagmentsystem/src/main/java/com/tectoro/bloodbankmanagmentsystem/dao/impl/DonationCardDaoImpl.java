package com.tectoro.bloodbankmanagmentsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.sql.Template;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.tectoro.bloodbankmanagmentsystem.dao.DonationCardDao;
import com.tectoro.bloodbankmanagmentsystem.dao.RecipientTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donartransactiondomain;
import com.tectoro.bloodbankmanagmentsystem.domain.DonationCarddomain;

@Repository
public class DonationCardDaoImpl implements DonationCardDao {

	@Autowired
	private JdbcTemplate template;
	@Autowired
	private RecipientTransactionDao dao;

	@Override
	public DonationCarddomain getaddDonationCard(DonationCarddomain carddomain) {

		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert ");
			sqlQuery.append("into ");
			sqlQuery.append("donationcard");
			sqlQuery.append("(donor_card_id,donor_id)");
			sqlQuery.append(" values(");
			sqlQuery.append(carddomain.getDonorCardId() + ",");
			sqlQuery.append(carddomain.getDonars().getDonor_id() + ")");

			template.execute(sqlQuery.toString());

		} catch (Exception e) {
			throw e;
		}
		return carddomain;
	}

	@Override
	public DonationCarddomain getDonation(int donorCardId) {

		DonationCarddomain carddomain = new DonationCarddomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from  ");
			sqlQuery.append("donationcard");
			sqlQuery.append(" where ");
			sqlQuery.append("donor_card_id =");
			sqlQuery.append(donorCardId);
			carddomain = template.query(sqlQuery.toString(), new ResultSetExtractor<DonationCarddomain>() {

				@Override
				public DonationCarddomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					DonationCarddomain res = new DonationCarddomain();
					while (rs.next()) {
						res.setDonorCardId(rs.getInt("donor_card_id"));

						Donardomain domain = new Donardomain();
						domain.setDonor_id(rs.getInt("donor_id"));
						res.setDonars(domain);

					}
					return res;
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return carddomain;
	}

	@Override
	public int deleteDonationCardByDonarID(int donor_id) {
		int flag = 0;
		int donarcardId=0;
		try {
			StringBuilder sqlQuery1 = new StringBuilder();
			sqlQuery1.append("select ");
			sqlQuery1.append("* from  ");
			sqlQuery1.append("donationcard ");
			sqlQuery1.append("where ");
			sqlQuery1.append("donor_id=");
			sqlQuery1.append(donor_id);

			DonationCarddomain carddomain = new DonationCarddomain();
			carddomain = template.query(sqlQuery1.toString(), new ResultSetExtractor<DonationCarddomain>() {

				@Override
				public DonationCarddomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					DonationCarddomain res = new DonationCarddomain();
					while (rs.next()) {
						res.setDonorCardId(rs.getInt("donor_card_id"));

						Donardomain domain = new Donardomain();
						domain.setDonor_id(rs.getInt("donor_id"));
						res.setDonars(domain);
						

					}
					return res;
				}
			});
			if(carddomain!=null) {
				donarcardId=carddomain.getDonorCardId();
				return donarcardId;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int deleteDonationCard(int donor_id) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("donationcard ");
			sqlQurery.append("where ");
			sqlQurery.append("donor_id =");
			sqlQurery.append(donor_id);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	

}
