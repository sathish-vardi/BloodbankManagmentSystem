package com.tectoro.bloodbankmanagmentsystem.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tectoro.bloodbankmanagmentsystem.dao.BloodTypeDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.model.BloodTypemodel;
import com.tectoro.bloodbankmanagmentsystem.service.BloodTypeService;

@Service
public class BloodTypeServiceImpl implements BloodTypeService {

	@Autowired
	private BloodTypeDao blooddao;

	@Override
	public BloodTypemodel addBloodType(BloodTypemodel inputmodel) {

		BloodTypedomain domain = new BloodTypedomain();
		domain.setName(inputmodel.getName());

		BloodTypedomain output = new BloodTypedomain();
		output = blooddao.addBloodType(domain);

		BloodTypemodel model = new BloodTypemodel();
		model.setName(output.getName());
		model.setBlood_type_id(String.valueOf(output.getBlood_type_id()));

		return model;
	}

	@Override
	public BloodTypemodel updateBloodType(BloodTypemodel bloodtype) {
		BloodTypedomain domain = new BloodTypedomain();
		domain.setBlood_type_id(Integer.parseInt(bloodtype.getBlood_type_id()));
		domain.setName(bloodtype.getName());

		BloodTypedomain output = new BloodTypedomain();
		output = blooddao.updateBloodType(domain);

		BloodTypemodel model = new BloodTypemodel();
		model.setName(output.getName());
		model.setBlood_type_id(String.valueOf(output.getBlood_type_id()));

		return model;
	}

	@Override
	public BloodTypemodel getBloodType(Integer blood_type_id) throws Exception {
		if (blood_type_id != null) {
			BloodTypedomain domain = new BloodTypedomain();

			domain = blooddao.getBloodType(blood_type_id);
			if (domain != null) {
				BloodTypemodel model = new BloodTypemodel();
				model.setBlood_type_id(String.valueOf(domain.getBlood_type_id()));
				model.setName(domain.getName());
				return model;
			}
		} else {
			throw new Exception("in service");
		}
		return null;
	}

	@Override
	public int deleteBloodType(int blood_type_id) {

		return blooddao.deleteBloodType(blood_type_id);
	}

	@Override
	public String CheckingBloodType(String name) {
		return blooddao.CheckBloodType(name);
	}

	
}
