package com.tectoro.bloodbankmanagmentsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.tectoro.bloodbankmanagmentsystem.dao.RecipientTransactionDao;
import com.tectoro.bloodbankmanagmentsystem.domain.BloodTypedomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donardomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Donartransactiondomain;
import com.tectoro.bloodbankmanagmentsystem.domain.DonationCarddomain;
import com.tectoro.bloodbankmanagmentsystem.domain.RecipientTransactiondomain;
import com.tectoro.bloodbankmanagmentsystem.domain.Recipientdomain;

@Repository
public class RecipientTransactionDaoImpl implements RecipientTransactionDao {

	@Autowired
	JdbcTemplate template;

	@Override
	public RecipientTransactiondomain addRecipient(RecipientTransactiondomain domain) {
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert ");
			sqlQuery.append("into ");
			sqlQuery.append("recipenttransaction ");
			sqlQuery.append("(recipent,blood_type_id,");
			sqlQuery.append("recipient_request,date,");
			sqlQuery.append("donor_card_id) ");
			sqlQuery.append("values(?,?,?,?,?)");
			KeyHolder keyHolder = new GeneratedKeyHolder();
			template.update(new PreparedStatementCreator() {

				@Override
				public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					PreparedStatement ps = con.prepareStatement(sqlQuery.toString(),
							new String[] { "recipient_trans_id" });
					ps.setInt(1, domain.getRecepients().getRecipentID());
					ps.setInt(2, domain.getBloodtypes().getBlood_type_id());
					ps.setString(3, domain.getRecipientRequest());
					ps.setDate(4, domain.getDate());
					ps.setInt(5, domain.getDonationcards().getDonorCardId());
					return ps;
				}
			}, keyHolder);
			domain.setRecipientTransId(keyHolder.getKey().intValue());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public RecipientTransactiondomain getrecipientTransaction(int domain) {

		RecipientTransactiondomain domain1 = new RecipientTransactiondomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("recipenttransaction ");
			sqlQuery.append("where ");
			sqlQuery.append("recipient_trans_id=");
			sqlQuery.append(domain);
			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<RecipientTransactiondomain>() {

				@Override
				public RecipientTransactiondomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					RecipientTransactiondomain res = new RecipientTransactiondomain();
					while (rs.next()) {
						res.setDate(rs.getDate("date"));
						res.setRecipientRequest(rs.getString("recipient_request"));
						res.setRecipientTransId(rs.getInt("recipient_trans_id"));
						BloodTypedomain bloodTypedomain = new BloodTypedomain();
						bloodTypedomain.setBlood_type_id(rs.getInt("blood_type_id"));
						res.setBloodtypes(bloodTypedomain);
						DonationCarddomain carddomain = new DonationCarddomain();
						carddomain.setDonorCardId(rs.getInt("donor_card_id"));
						res.setDonationcards(carddomain);
						Recipientdomain recipientdomain = new Recipientdomain();
						recipientdomain.setRecipentID(rs.getInt("recipent"));
						res.setRecepients(recipientdomain);

					}
					return res;
				}
			});
		} catch (Exception e) {
			throw e;
		}
		return domain1;
	}

	@Override
	public RecipientTransactiondomain updateRecipentTransaction(RecipientTransactiondomain domain) {
		RecipientTransactiondomain domain1 = new RecipientTransactiondomain();
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("update recipenttransaction set ");
			if (domain.getDate() != null) {
				sqlQuery.append("date='" + domain.getDate() + "', ");
			}
			if (domain.getRecipientRequest() != null) {
				sqlQuery.append("recipient_request='" + domain.getRecipientRequest() + "', ");
			}
			if (domain.getBloodtypes().getBlood_type_id() > 0) {
				sqlQuery.append("blood_type_id=" + domain.getBloodtypes().getBlood_type_id() + ", ");
			}
			if (domain.getDonationcards().getDonorCardId() > 0) {
				sqlQuery.append("donor_card_id=" + domain.getDonationcards().getDonorCardId() + ", ");
			}
			if (domain.getRecepients().getRecipentID() > 0) {
				sqlQuery.append("recipent=" + domain.getRecepients().getRecipentID() + ", ");
			}
			StringBuilder builder = new StringBuilder();
			builder.append(sqlQuery.substring(0, sqlQuery.length() - 2));

			builder.append(" where ");
			builder.append("recipient_trans_id=");
			builder.append(domain.getRecipientTransId());

			template.batchUpdate(builder.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int deleteTransaction(int blood_type_id) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("recipenttransaction ");
			sqlQurery.append("where ");
			sqlQurery.append("blood_type_id = ");
			sqlQurery.append(blood_type_id);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int deleteTransactionById(int donorCardId) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("recipenttransaction ");
			sqlQurery.append("where ");
			sqlQurery.append("donor_card_id = ");
			sqlQurery.append(donorCardId);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int deleteTransactionById(int donarcardId, int recipientId) {
		int flag = 0;
		try {
			StringBuilder sqlQurery = new StringBuilder();
			sqlQurery.append("delete ");
			sqlQurery.append("from ");
			sqlQurery.append("recipenttransaction ");
			sqlQurery.append("where ");
			sqlQurery.append("recipent =");
			sqlQurery.append(recipientId + " and ");
			sqlQurery.append("donor_card_id = ");
			sqlQurery.append(donarcardId);
			flag = template.update(sqlQurery.toString());
			if (flag == 1) {
				return flag;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public String CheckingDate(int recipientTransId) {
		RecipientTransactiondomain domain1 = null;
		try {
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select ");
			sqlQuery.append("* from ");
			sqlQuery.append("recipenttransaction ");
			sqlQuery.append("where ");
			sqlQuery.append("recipent=");
			sqlQuery.append(recipientTransId);
			domain1 = template.query(sqlQuery.toString(), new ResultSetExtractor<RecipientTransactiondomain>() {

				@Override
				public RecipientTransactiondomain extractData(ResultSet rs) throws SQLException, DataAccessException {
					RecipientTransactiondomain res = new RecipientTransactiondomain();
					while (rs.next()) {
						res.setDate(rs.getDate("date"));
						res.setRecipientRequest(rs.getString("recipient_request"));
						res.setRecipientTransId(rs.getInt("recipient_trans_id"));
						BloodTypedomain bloodTypedomain = new BloodTypedomain();
						bloodTypedomain.setBlood_type_id(rs.getInt("blood_type_id"));
						res.setBloodtypes(bloodTypedomain);
						DonationCarddomain carddomain = new DonationCarddomain();
						carddomain.setDonorCardId(rs.getInt("donor_card_id"));
						res.setDonationcards(carddomain);
						Recipientdomain recipientdomain = new Recipientdomain();
						recipientdomain.setRecipentID(rs.getInt("recipent"));
						res.setRecepients(recipientdomain);

					}
					return res;
				}
			});
			if(domain1.getDate()!=null) {
				return String.valueOf(domain1.getDate());
			}
			else {
				return "no recipent transartion occured ";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}

}
