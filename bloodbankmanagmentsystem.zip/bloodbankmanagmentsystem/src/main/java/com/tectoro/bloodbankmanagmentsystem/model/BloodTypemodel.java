package com.tectoro.bloodbankmanagmentsystem.model;

import java.util.List;

public class BloodTypemodel {
	String blood_type_id;
	String name;

	public String getBlood_type_id() {
		return blood_type_id;
	}

	public void setBlood_type_id(String blood_type_id) {
		this.blood_type_id = blood_type_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
