package com.tectoro.bloodbankmanagmentsystem.dao;

import com.tectoro.bloodbankmanagmentsystem.domain.RecipientTransactiondomain;

public interface RecipientTransactionDao {

	RecipientTransactiondomain addRecipient(RecipientTransactiondomain domain);

	RecipientTransactiondomain getrecipientTransaction(int recipientTransId);

	RecipientTransactiondomain updateRecipentTransaction(RecipientTransactiondomain domain);

	int deleteTransaction(int recipient_trans_id);

	int deleteTransactionById(int donorCardId);

	int deleteTransactionById(int donarcardId, int recipientId);

	String CheckingDate(int recipientTransId);

}
