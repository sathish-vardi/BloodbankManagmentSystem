package com.tectoro.bloodbankmanagmentsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloodbankmanagmentsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
